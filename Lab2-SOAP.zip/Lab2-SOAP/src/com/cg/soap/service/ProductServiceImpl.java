package com.cg.soap.service;

import java.util.List;

import com.cg.soap.beans.ProductBean;
import com.cg.soap.dao.IProductDao;
import com.cg.soap.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService {

	IProductDao dao = new ProductDaoImpl();
	public ProductServiceImpl() {
		
	}

	@Override
	public List<ProductBean> getAllProducts() {
		return  dao.getAllProducts();
	}

	@Override
	public ProductBean addProduct(ProductBean productBean) {
		return dao.addProduct(productBean);
	}

}
