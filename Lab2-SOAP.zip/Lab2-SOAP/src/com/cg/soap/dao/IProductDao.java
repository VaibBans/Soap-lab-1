package com.cg.soap.dao;

import java.util.List;

import com.cg.soap.beans.ProductBean;

public interface IProductDao {
	public List<ProductBean> getAllProducts();
	public ProductBean addProduct(ProductBean productBean);
}
