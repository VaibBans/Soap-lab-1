package com.cg.soap.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.soap.beans.ProductBean;
import com.cg.soap.staticdb.ProductDB;

public class ProductDaoImpl implements IProductDao {

	static HashMap<Integer, ProductBean> productsList = ProductDB.getProductNameMap();
	public ProductDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<ProductBean> getAllProducts() {
		List<ProductBean> products = new ArrayList<ProductBean>(productsList.values());
		return products;
	}

	@Override
	public ProductBean addProduct(ProductBean productBean) {
		productsList.put(productBean.getProdId(), productBean);
		return productBean;
	}
}