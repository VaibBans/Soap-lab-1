package com.cg.soap.staticdb;

import java.util.HashMap;

import com.cg.soap.beans.ProductBean;

public class ProductDB {

static HashMap<Integer, ProductBean> prodNameMap = getProductNameMap();
	
	static {
		if (prodNameMap == null) {
			prodNameMap = new HashMap<Integer, ProductBean>();
			ProductBean lappy= new ProductBean("Laptop",101,45678.34F);
			ProductBean iPad= new ProductBean("IPad",102,65678.84F);
			ProductBean iPhone= new ProductBean("IPhone",103,84678.34F);
			ProductBean iPod= new ProductBean("IPod",104,1200.99F);
			ProductBean hardDisk= new ProductBean("Hard Disk",105,5000.0F);
			ProductBean dataCables= new ProductBean("Data Cables",106,2000.15F);
			ProductBean wristBand= new ProductBean("Fit Bit Wrist Band",107,5000.78F);
			ProductBean armSleeves= new ProductBean("Arm Sleeves",108,500.12F);
			ProductBean adapter= new ProductBean("Adapter",109,4000.26F);
			ProductBean samTab= new ProductBean("Samsung Tab",110,75678.0F);
			ProductBean dvd= new ProductBean("DVD",234,345323.0F);
			
			prodNameMap.put(1, lappy);
			prodNameMap.put(2, iPad);
			prodNameMap.put(3, iPhone);
			prodNameMap.put(4, iPod);
			prodNameMap.put(5, hardDisk);
			prodNameMap.put(6, dataCables);
			prodNameMap.put(7, wristBand);
			prodNameMap.put(8, armSleeves);
			prodNameMap.put(9, adapter);
			prodNameMap.put(10, samTab);
			prodNameMap.put(11, dvd);
		}

	}
	/**
	 * This is a getter method of HashMap
	 * @return HashMap<Integer, Country>
	 */
	public static HashMap<Integer, ProductBean> getProductNameMap() {
		return prodNameMap;
	}
}
