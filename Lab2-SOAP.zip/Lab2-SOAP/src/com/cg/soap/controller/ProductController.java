package com.cg.soap.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.soap.beans.ProductBean;
import com.cg.soap.service.ProductService;
import com.cg.soap.service.ProductServiceImpl;

/**
 * Servlet implementation class ProductController
 */
@Path("/products")
public class ProductController {
	private static final long serialVersionUID = 1L;
    ProductService service;   
    public ProductController() {
    	service = new ProductServiceImpl(); 
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<ProductBean> getProducts() {
//    	System.out.println("In method");
		List<ProductBean> listOfProducts = service.getAllProducts();
		return listOfProducts;
	}
    @POST
	@Produces(MediaType.APPLICATION_JSON)
	public ProductBean addProduct(@FormParam("prodId") int prodId,
			@FormParam("prodName") String prodName,
			@FormParam("prodPrice") float prodPrice) {
		ProductBean product = new ProductBean();
		product.setProdId(prodId);
		product.setProdName(prodName);
		product.setPrice(prodPrice);
		
		return service.addProduct(product);
	}
}
