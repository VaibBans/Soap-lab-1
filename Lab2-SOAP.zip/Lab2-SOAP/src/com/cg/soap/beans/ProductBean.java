package com.cg.soap.beans;

public class ProductBean {

	private String prodName;
	private int prodId;
	private float price;

	public ProductBean() {
		super();
	}
	public ProductBean(String prodName, int prodId, float price) {
		super();
		this.prodName = prodName;
		this.prodId = prodId;
		this.price = price;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
}